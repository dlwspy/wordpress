<?php
return array(
//配置项名=>配置项值
);