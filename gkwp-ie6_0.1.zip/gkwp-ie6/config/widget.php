<?php
/**
 * Copyright (c) 2012 3g4k.com.
 * All rights reserved.
 * @package     gkwp
 * @author      luofei614 <weibo.com/luofei614>
 * @copyright   2012 3g4k.com.
 */
return array(
   'search'=>array('title'=>''),
   'recent-comments'=>array('title'=>'最近评论','number'=>3),
   'recent-posts'=>array('title'=>'最近文章','number'=>5)
);