<?php
/**
 * Copyright (c) 2012 3g4k.com.
 * All rights reserved.
 * @package     gkwp
 * @author      luofei614 <weibo.com/luofei614>
 * @copyright   2012 3g4k.com.
 */
return array(
    array(
            'name' => '网站右侧',
            'id' => 'gkwp-right',
            'before_widget' => '<aside id="%1$s" class="widget well %2$s">',
            'after_widget' => "</aside>",
            'before_title' => '<h3 class="right_title">',
            'after_title' => '</h3>',
           'default'=>'search,recent-comments,recent-posts',
         )
);