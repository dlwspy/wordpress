<?php
/**
 * Copyright (c) 2012 3g4k.com.
 * All rights reserved.
 * @package     gkwp
 * @author      luofei614 <weibo.com/luofei614>
 * @copyright   2012 3g4k.com.
 */
if(!dynamic_sidebar('gkwp-right')){
    _e('右侧展示没有内容','gkwp');
}